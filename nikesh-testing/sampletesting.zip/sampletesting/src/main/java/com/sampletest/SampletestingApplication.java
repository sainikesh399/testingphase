package com.sampletest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SampletestingApplication {

	public static void main(String[] args) {
		SpringApplication.run(SampletestingApplication.class, args);
	}

}
