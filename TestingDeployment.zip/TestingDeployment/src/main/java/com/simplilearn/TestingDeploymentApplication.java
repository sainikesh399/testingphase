package com.simplilearn;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TestingDeploymentApplication {

	public static void main(String[] args) {
		SpringApplication.run(TestingDeploymentApplication.class, args);
	}

}
